plate-box
=========

HTML5 boiler plat with bootstrap support and fontawesome support... Included semantic HTML :P
